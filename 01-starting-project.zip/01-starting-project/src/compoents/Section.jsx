import React, { Children } from 'react'

export default function Section({title,Children}) {
  return (
   
    <Section>
        <h2>{title}</h2>
        {Children}
    </Section>
  )
}
