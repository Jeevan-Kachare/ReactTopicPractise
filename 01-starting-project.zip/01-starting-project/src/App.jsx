import { CORE_CONCEPTS, EXAMPLES } from './data';
import Header from './compoents/Header/Header';
import CoreConcepts from './compoents/CoreConcept';
import TabButton from './compoents/TabButton';

import { useState } from 'react';
import Example from './compoents/Example';

function App() {


  return (
    <div>
      <Header />

      <main>
        <CoreConcepts/>
        <Example/>
      </main>
    </div>
  );
}

export default App;